-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 08-05-2017 a las 11:46:22
-- Versión del servidor: 5.5.40
-- Versión de PHP: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `turistea`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `galeria`
--

CREATE TABLE IF NOT EXISTS `galeria` (
  `Titulo` varchar(30) NOT NULL,
  `Imagen` text NOT NULL,
  `Anecdota` text NOT NULL,
  `Lugar` varchar(30) NOT NULL,
  `Autor` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `gastronomia`
--

CREATE TABLE IF NOT EXISTS `gastronomia` (
  `Nombre` varchar(30) NOT NULL,
  `Imagen` varchar(20) NOT NULL,
  `Direccion` varchar(30) NOT NULL,
  `Telefono` int(9) NOT NULL,
  `Horario` text NOT NULL,
  `Llegada` text NOT NULL,
  `Plato estrella` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lugares`
--

CREATE TABLE IF NOT EXISTS `lugares` (
  `Tipo` enum('Teatro','Museo','Cine','Parque') NOT NULL,
  `Nombre` varchar(30) NOT NULL,
  `Imagen` varchar(20) NOT NULL,
  `Direccion` varchar(50) NOT NULL,
  `Telefono` int(9) NOT NULL,
  `Horario` text NOT NULL,
  `Llegada` text NOT NULL,
  `Precio` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `noticias`
--

CREATE TABLE IF NOT EXISTS `noticias` (
  `Titulo` varchar(25) NOT NULL,
  `Imagen` varchar(25) NOT NULL,
  `Contenido` text NOT NULL,
  `Fuente` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rutas`
--

CREATE TABLE IF NOT EXISTS `rutas` (
  `Nombre` varchar(30) NOT NULL,
  `Mapa` varchar(30) NOT NULL,
  `Duracion` int(5) NOT NULL,
  `Punto_partida` varchar(30) NOT NULL,
  `Punto_destino` varchar(30) NOT NULL,
  `Descripcion` text NOT NULL,
  `Fotos` varchar(20) NOT NULL,
  `Contenido` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tienda`
--

CREATE TABLE IF NOT EXISTS `tienda` (
  `Nombre` varchar(25) NOT NULL,
  `Imagen` varchar(25) NOT NULL,
  `Precio` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `Nombre` varchar(30) NOT NULL,
  `Id_usuario` varchar(25) NOT NULL,
  `Contrasenia` varchar(20) NOT NULL,
  `E-mail` varchar(30) NOT NULL,
  `Tipo` enum('admin','normal') NOT NULL DEFAULT 'normal'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `visitas`
--

CREATE TABLE IF NOT EXISTS `visitas` (
  `Nombre` varchar(30) NOT NULL,
  `Imagen` varchar(20) NOT NULL,
  `Descripcion` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `galeria`
--
ALTER TABLE `galeria`
 ADD PRIMARY KEY (`Titulo`,`Autor`);

--
-- Indices de la tabla `gastronomia`
--
ALTER TABLE `gastronomia`
 ADD PRIMARY KEY (`Nombre`);

--
-- Indices de la tabla `lugares`
--
ALTER TABLE `lugares`
 ADD PRIMARY KEY (`Nombre`);

--
-- Indices de la tabla `noticias`
--
ALTER TABLE `noticias`
 ADD PRIMARY KEY (`Titulo`);

--
-- Indices de la tabla `rutas`
--
ALTER TABLE `rutas`
 ADD PRIMARY KEY (`Nombre`);

--
-- Indices de la tabla `tienda`
--
ALTER TABLE `tienda`
 ADD PRIMARY KEY (`Nombre`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
 ADD PRIMARY KEY (`Id_usuario`), ADD UNIQUE KEY `E-mail` (`E-mail`);

--
-- Indices de la tabla `visitas`
--
ALTER TABLE `visitas`
 ADD PRIMARY KEY (`Nombre`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
